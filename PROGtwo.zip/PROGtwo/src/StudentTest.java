import static org.junit.jupiter.api.Assertions.*;

class StudentTest {

    @org.junit.jupiter.api.BeforeEach
    void TestSaveStudent() {
    }

    @org.junit.jupiter.api.BeforeEach
    void TestSearchStudent() {
    }

    @org.junit.jupiter.api.BeforeEach
    void TestSearchStudent_() {
    }



    @org.junit.jupiter.api.AfterEach
    void TestStudentAge_StudentAgeInvalid() {
    }

    @org.junit.jupiter.api.BeforeEach
    void TestStudentAge_StudentAgeInvalidCharacter() {
    }


    @org.junit.jupiter.api.Test
    void testToString() {
    }
}